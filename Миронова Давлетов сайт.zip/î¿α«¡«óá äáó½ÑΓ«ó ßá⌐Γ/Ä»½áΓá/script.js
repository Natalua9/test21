const form = document.querySelector('form');
const cardNumberInput = document.getElementById('cardNumber');
const cardNameInput = document.getElementById('cardName');
const cardSurnameInput = document.getElementById('cardSurname');
const cardExpireInput = document.getElementById('cardExpire');
const cardCvvInput = document.getElementById('cardCvv');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  
  // Проверяем валидность номера карты
  const cardNumberValue = cardNumberInput.value.trim();
  if (!isValidCardNumber(cardNumberValue)) {
    alert('Некорректный номер карты');
    return;
  }
  
  // Проверяем заполненность полей имени и фамилии на карте
  const cardNameValue = cardNameInput.value.trim();
  const cardSurnameValue = cardSurnameInput.value.trim();
  if (cardNameValue === '' || cardSurnameValue === '') {
    alert('Введите имя и фамилию на карте');
    return;
  }
  
  // Проверяем валидность срока действия карты
  const cardExpireValue = cardExpireInput.value;
  if (!isValidCardExpire(cardExpireValue)) {
    alert('Некорректный срок действия карты');
    return;
  }
  
  // Проверяем валидность CVV кода
  const cardCvvValue = cardCvvInput.value.trim();
  if (!isValidCardCvv(cardCvvValue)) {
    alert('Некорректный CVV код');
    return;
  }
  
  // Если все проверки прошли успешно, отправляем данные на сервер и переходим на страницу подтверждения
  alert('Данные карты отправлены на сервер');
  window.location.href = 'confirmation.html';
});

// Функция для проверки валидности номера карты
function isValidCardNumber(cardNumber) {
  const regex = /^[0-9]{16}$/;
  return regex.test(cardNumber);
}

// Функция для проверки валидности срока действия карты
function isValidCardExpire(cardExpire) {
  const today = new Date();
  const expireDate = new Date(cardExpire + '-01');
  return expireDate > today;
}

// Функция для проверки валидности CVV кода
function isValidCardCvv(cardCvv) {
  const regex = /^[0-9]{3}$/;
  return regex.test(cardCvv);
}