

// const btnPrev = document.querySelector('.slider__btn--left');
// const btnNext = document.querySelector('.slider__btn--right');

// const slide1 = document.querySelector('.slide__first');
// const slide2 = document.querySelector('.slide__second');

// let isFirstSlide = true;


// function switchRight() {
//     console.log('hello');
//     slide2.style.display = "block";
//     slide1.style.display = "none";
//     isFirstSlide = false;
// }

// function switchLeft() {
//     console.log('hello');
//     slide1.style.display = "block";
//     slide2.style.display = "none";
//     isFirstSlide = true;
// }


// setInterval(() => {
//     if (isFirstSlide) {
//         switchRight();
//     } else {
//         switchLeft();
//     }
// }, 10000)

// btnPrev.addEventListener('click', switchLeft);
// btnNext.addEventListener('click', switchRight);
// var slider = document.getElementById("slider"); // получаем элемент слайдера
// var slides = slider.getElementsByClassName("slide"); // получаем все слайды внутри слайдера
// var currentSlide = 0; // переменная для хранения текущего слайда

// // функция для отображения следующего слайда
// function showNextSlide() {
//     // скрываем текущий слайд
//     slides[currentSlide].style.opacity = "0";
//     // увеличиваем переменную текущего слайда на 1
//     currentSlide++;
//     // если текущий слайд больше, чем количество слайдов, то переходим к первому слайду
//     if (currentSlide >= slides.length) 
//         currentSlide = 0;
    
//     // отображаем следующий слайд
//     slides[currentSlide].style.opacity = "1";
// }

// // вызываем функцию для отображения следующего слайда каждые 3 секунды
// setInterval(showNextSlide, 3000);
const btnTop = document.querySelector('.buttonTop');

btnTop.addEventListener('click', () => {
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0; // For Safari
});