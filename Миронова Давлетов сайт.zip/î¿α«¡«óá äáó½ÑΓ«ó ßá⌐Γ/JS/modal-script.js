let btn = document.getElementById("show-modal");

btn.addEventListener("click", showModal);

function showModal() {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.top = "50%"
}



let but = document.getElementById("show-modal2");

but.addEventListener("click", showModal2);

function showModal2() {
    let modal = document.getElementsByClassName("modal2")[0];
    modal.style.top = "50%"
}