const btnTop = document.querySelector('.buttonTop');

btnTop.addEventListener('click', () => {
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0; // For Safari
});
