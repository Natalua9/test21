function submitForm() {
    var emailInput = document.querySelector(".footer-input");
    var email = emailInput.value;
    emailInput.value = "";
    alert ("Спасибо, наш менеджер обязательно с вами свяжется!");
}