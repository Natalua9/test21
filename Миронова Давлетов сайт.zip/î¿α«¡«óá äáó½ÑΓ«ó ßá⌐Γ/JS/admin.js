function checkLogin() {
    var login = document.getElementById("login").value;
    var password = document.getElementById("password").value;
  
    if (login === "admin" && password === "admin") {
      window.location.href = "Панель Администратора/1 страница управление пользователями/index.html";
    } else {
      window.location.href = "личный кабинет/index.html";
    }
  }